//
//  ViewController.m
//  TMYView
//
//  Created by TMY on 2018/11/5.
//  Copyright © 2018 tmy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
